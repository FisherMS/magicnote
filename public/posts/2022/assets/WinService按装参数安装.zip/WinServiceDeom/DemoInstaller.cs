﻿using System.ComponentModel;
using System.Configuration;
using System.Configuration.Install;
using System.IO;
using System.Reflection;
using System.ServiceProcess;

namespace WinServiceDeom
{
    /// <summary>
    /// 服务安装，安装后立即启动
    /// </summary>
    [RunInstaller(true)]
    public partial class DemoInstaller : Installer
    {
        protected string ConfigServiceName = Path.GetFileNameWithoutExtension(Assembly.GetEntryAssembly().CodeBase); 
        protected string ConfigDescription = null;

        public DemoInstaller()
        {
            InitializeComponent();//在安装中取得配置中的名字必须。
            Committed += ServiceInstallerCommitted;

            var serviceName  = ConfigurationManager.AppSettings["ServiceName"];
            var desc = ConfigurationManager.AppSettings["ServiceDescription"];
            if (!string.IsNullOrEmpty(serviceName))ConfigServiceName = serviceName;
            if (!string.IsNullOrEmpty(desc))ConfigDescription = desc;

            var processInstaller = new ServiceProcessInstaller { Account = ServiceAccount.LocalSystem };
            var serviceInstaller = new ServiceInstaller
                {
                    //自动启动服务，手动的话，每次开机都要手动启动。
                    StartType = ServiceStartMode.Automatic,

                    ServiceName = ConfigServiceName,
                    Description = ConfigDescription
                };

            Installers.Add(serviceInstaller);
            Installers.Add(processInstaller);
        }

        /// <summary>
        /// 服务安装完成后自动启动
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void ServiceInstallerCommitted(object sender, InstallEventArgs e)
        {
            var controller = new ServiceController(ConfigServiceName);
            controller.Start();
        }


    }
}
