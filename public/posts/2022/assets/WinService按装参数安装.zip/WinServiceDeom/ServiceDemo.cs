﻿using System;
using System.Net;
using System.Net.Sockets;
using System.ServiceProcess;
using System.Text;
using System.Threading;

namespace WinServiceDeom
{
    partial class ServiceDemo : ServiceBase
    {
        public ServiceDemo()
        {
            InitializeComponent();
            _udpSender = new UdpSender();
        }

        private readonly UdpSender _udpSender;

        protected bool IsRun;

        protected override void OnStart(string[] args)
        {
            Start();
        }

        public void Start()
        {
            IsRun = true;
            _udpSender.Send("Service is starting...");
            ThreadPool.QueueUserWorkItem(x =>
            {
                while (IsRun)
                {
                    var msg = string.Format("[{0:HH:mm:ss ffff}]Demo inteval out。", DateTime.Now);
                    _udpSender.Send(msg);
                    Thread.Sleep(2000);
                }
            });
        }

        protected override void OnStop()
        {
            IsRun = false;
            _udpSender.Send("Service is stoped.");
        }

        public class UdpSender
        {
            private readonly UdpClient _client;
            private readonly IPEndPoint _endPoint;

            public UdpSender()
            {
                _client = new UdpClient();
                _endPoint = new IPEndPoint(IPAddress.Broadcast, 60000);
            }

            public void Send(string msg)
            {
                var sendBytes = Encoding.ASCII.GetBytes(msg);
                try
                {
                    _client.Send(sendBytes, sendBytes.Length, _endPoint);//发送字节数组到指定的网络端点
                    Console.WriteLine(msg);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
        }

    }
}
