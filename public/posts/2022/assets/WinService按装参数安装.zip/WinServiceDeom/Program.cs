﻿using System;
using System.IO;
using System.Reflection;
using System.ServiceProcess;

namespace WinServiceDeom
{
    internal static class Program
    {
        /// <summary>
        /// 应用程序的主入口点。
        /// <remarks>要以管理员权限运行才可以</remarks>
        /// </summary>
        static void Main(string[] args)
        {
            var x = Assembly.GetEntryAssembly();
            var y = x.CodeBase;

            Console.WriteLine(y);


            //无参数时直接运行服务
            if ((!IsMono && !Environment.UserInteractive)//Windows Service
                || (IsMono && !AppDomain.CurrentDomain.FriendlyName.Equals(Path.GetFileName(Assembly.GetEntryAssembly().CodeBase))))//MonoService
            {
                RunAsService();
                return;
            }

            if (args != null && args.Length > 0)
            {
                if (args[0].Equals("-i", StringComparison.OrdinalIgnoreCase))
                {
                    SelfInstaller.InstallMe();
                    return;
                }
                if (args[0].Equals("-u", StringComparison.OrdinalIgnoreCase))
                {
                    SelfInstaller.UninstallMe();
                    return;
                }
                if (args[0].Equals("-t", StringComparison.OrdinalIgnoreCase))
                {
                    Console.WriteLine("This is a test.:{0}",Assembly.GetExecutingAssembly().Location);
                    return;
                }
                Console.WriteLine("Invalid argument!");
                return;
            }

            RunAsConsole();
           
        }

        static void RunAsConsole()
        {
            var x = new ServiceDemo();
            x.Start();
            Console.ReadLine();
        }

        static void RunAsService()
        {
            var servicesToRun = new ServiceBase[] { new ServiceDemo()};
            ServiceBase.Run(servicesToRun);
        }

        private static bool IsMono
        {
            get
            {
                return Type.GetType("Mono.Runtime") != null;
            }
        }
    }
}
